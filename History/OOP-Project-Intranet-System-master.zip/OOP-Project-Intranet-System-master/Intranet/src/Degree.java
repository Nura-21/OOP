public enum Degree {
    BACHELOR,
    MASTER,
    PHD
}
