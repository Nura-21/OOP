public enum EmployeeTypes {
    MANAGEMENT,
    EDUCATIONAL,
    ADMINISTRATION,
    OTHER
}
