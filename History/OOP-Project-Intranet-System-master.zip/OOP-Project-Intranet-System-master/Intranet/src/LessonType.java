public enum LessonType {
    LECTURE,
    LABORATORY,
    PRACTICE
}
