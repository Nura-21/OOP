public interface Messageable {
    void sentMessage();
    String getMessage();
}
