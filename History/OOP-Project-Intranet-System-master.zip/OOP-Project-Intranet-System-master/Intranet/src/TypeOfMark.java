public enum TypeOfMark {
    FIRST_ATTESTATION,
    SECOND_ATTESTATION,
    FINAL
}
