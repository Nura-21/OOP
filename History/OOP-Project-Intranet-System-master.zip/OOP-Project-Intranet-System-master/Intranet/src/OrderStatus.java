public enum OrderStatus {
    NEW,
    ACCEPTED,
    REJECTED,
    DONE
}
