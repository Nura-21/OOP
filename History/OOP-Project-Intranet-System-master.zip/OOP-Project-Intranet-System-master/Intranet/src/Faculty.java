public enum Faculty {
    FIT,
    BS,
    MCM
}
