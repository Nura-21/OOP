public enum AcademicDegree {
    PROFESSOR,
    LECTURER,
    ASSISTANT,
    SENIOR_LECTURER
}
